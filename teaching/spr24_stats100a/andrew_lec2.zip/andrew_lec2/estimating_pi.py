import numpy as np
def est_pi(num_sims):
    count_in = 0
    for _ in range(num_sims):
        x, y = np.random.uniform(-1.0, 1.0, size=2)
        if x**2 + y**2 < 1:
            count_in += 1
    return 4 * (count_in / num_sims)

est_pi(10000)