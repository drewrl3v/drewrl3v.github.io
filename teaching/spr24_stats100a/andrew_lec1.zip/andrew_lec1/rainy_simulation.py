import numpy as np
import matplotlib.pyplot as plt

# Parameters that effect chances of rain/sun
alpha = 2/3
beta = 1/2
v0 = np.array([1., 0. ])

# The transition matrix
K = np.array([[alpha, 1 - alpha], 
              [beta, 1 - beta]])

# Loop for the first 8 days
v_list = []
for n in range(0,8):
    print("----")
    print("Day: ", n)
    v = v0 @ np.linalg.matrix_power(K, n)
    print("probabilities: ", v)
    v_list.append(v)

plt.plot(v_list)
plt.show()