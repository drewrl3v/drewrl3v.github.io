import numpy as np

def simulate_HT(num_sims):
    number_of_flips_per_trial = []
    for _ in range(num_sims):
        saw_HT = False
        trial = []
        while not saw_HT:
            # Lets say H = 1, T = 0
            flip = np.random.binomial(n=1, p=1/2)
            if len(trial) >= 1 and trial[-1] == 1 and flip == 0:
                saw_HT = True
            trial.append(flip)

        number_of_flips_per_trial.append(len(trial))
    return sum(number_of_flips_per_trial) / num_sims

simulate_HT(1000)