# Simulate coin flips
coin_flips <- 2 * rbinom(n = 100, size = 1, prob = 0.5) - 1

# Calculate cumulative sum to simulate the random walk
summing <- cumsum(coin_flips)

# Plot the random walk
par(bg = 'white')
plot(summing, type = "l", col = 'red', xlab = "Step", ylab = "Position",
     main = "Random Walk Simulation")