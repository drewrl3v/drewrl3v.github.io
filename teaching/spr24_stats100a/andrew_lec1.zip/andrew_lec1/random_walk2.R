simple_random_walk <- function(steps) {
  s <- 0
  res <- numeric(steps)
  for (i in 1:steps) {
    s <- s + sample(c(-1, 1), size = 1)
    res[i] <- s
  }
  return(res)
}

# Generate a simple random walk of 100 steps
ls <- simple_random_walk(100)

# Plot the random walk
par(bg = 'white')
plot(ls, type = "l", col = 'red', xlab = "Step", ylab = "Position",
 main = "Random Walk Simulation")